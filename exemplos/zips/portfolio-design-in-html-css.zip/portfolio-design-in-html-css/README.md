# Portfolio design in HTML/CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/hainersavimaa/pen/WGXXwp](https://codepen.io/hainersavimaa/pen/WGXXwp).

original by Jonathan Violassi: https://dribbble.com/shots/3002565-Resume/attachments/627315