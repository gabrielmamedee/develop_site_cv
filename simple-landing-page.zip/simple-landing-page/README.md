# Simple landing page

A Pen created on CodePen.io. Original URL: [https://codepen.io/areal_alien/pen/zYxWdxa](https://codepen.io/areal_alien/pen/zYxWdxa).

